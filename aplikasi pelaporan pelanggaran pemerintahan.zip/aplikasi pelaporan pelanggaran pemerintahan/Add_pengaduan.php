<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Add_pengaduan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('add_pengaduan1');
        $this->load->library('upload');
        $this->load->helper('text');
        $this->load->helper('string');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->load->model('M_user');
        if ($this->session->userdata('role_id') != NULL) {
            $data['title'] = 'Add Pengaduan';
            $post_id =  $this->session->userdata('username');
            $x['data'] = $this->M_user->get_user($post_id);
            $this->load->view('templates_front/header', $data);
            $this->load->view('add_pengaduan', $x);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }

    function anon()
    {
        $data['title'] = 'Add Pengaduan';
        $this->load->view('templates_front/header', $data);
        $this->load->view('add_pengaduan_anon', $data);
        $this->load->view('templates_front/footer', $data);
    }

    function add()
    {
        $config['upload_path'] = './assets/images/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
        $config['encrypt_name'] = TRUE;

        $this->upload->initialize($config);

        if (!empty($_FILES['filefoto']['name'])) {
            if ($this->upload->do_upload('filefoto')) {
                $img = $this->upload->data();
                //Compress Image
                $config['image_library'] = 'gd2';
                $config['source_image'] = './assets/images/' . $img['file_name'];
                $config['create_thumb'] = FALSE;
                $config['maintain_ratio'] = FALSE;
                $config['quality'] = '60%';
                $config['width'] = 500;
                $config['height'] = 320;
                $config['new_image'] = './assets/images/' . $img['file_name'];
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();

                $this->_create_thumbs($img['file_name']);
                date_default_timezone_set('Asia/Jakarta');

                $image = $img['file_name'];
                $judul = $this->input->post('judul');
                $nomor = date('my') . "-" . random_string('alpha', 6);
                $nama_anda = $this->input->post('nama_anda');
                $username = $this->input->post('username');
                $email = $this->input->post('email');
                $phone = $this->input->post('telepon');
                $nama_terlapor = $this->input->post('nama_terlapor');
                $jabatan = $this->input->post('jabatan');
                $uraian = $this->input->post('uraian');


                $this->add_pengaduan1->save_post($image, $judul, $nomor, $nama_anda, $username, $email, $phone, $nama_terlapor, $jabatan, $uraian);
                $data['title'] = 'Nomor Tiket anda';
                $no['no'] = $nomor;
                $this->load->view('templates_front/header', $data);
                $this->load->view('nomor', $no);
                $this->load->view('templates_front/footer');
            } else {
                echo $this->session->set_flashdata('msg', 'warning');
                redirect('add_pengaduan');
            }
        } else {
            redirect('manage_news');
        }
    }

    function add_anon()
    {
        $config['upload_path'] = './assets/images/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
        $config['encrypt_name'] = TRUE;

        $this->upload->initialize($config);

        if (!empty($_FILES['filefoto']['name'])) {
            if ($this->upload->do_upload('filefoto')) {
                $img = $this->upload->data();
                //Compress Image
                $config['image_library'] = 'gd2';
                $config['source_image'] = './assets/images/' . $img['file_name'];
                $config['create_thumb'] = FALSE;
                $config['maintain_ratio'] = FALSE;
                $config['quality'] = '60%';
                $config['width'] = 500;
                $config['height'] = 320;
                $config['new_image'] = './assets/images/' . $img['file_name'];
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();

                $this->_create_thumbs($img['file_name']);
                date_default_timezone_set('Asia/Jakarta');

                $image = $img['file_name'];
                $judul = $this->input->post('judul');
                $nomor = date('my') . "-" . random_string('alpha', 6);
                $nama_terlapor = $this->input->post('nama_terlapor');
                $jabatan = $this->input->post('jabatan');
                $uraian = $this->input->post('uraian');


                $this->add_pengaduan1->save_anon($image, $judul, $nomor, $nama_terlapor, $jabatan, $uraian);
                $data['title'] = 'Nomor Tiket anda';
                $no['no'] = $nomor;
                $this->load->view('templates_front/header_anon', $data);
                $this->load->view('nomor', $no);
                $this->load->view('templates_front/footer', $data);
            } else {
                echo $this->session->set_flashdata('msg', 'warning');
                redirect('add_pengaduan');
            }
        } else {
            redirect('error');
        }
    }

    function _create_thumbs($file_name)
    {
        // Image resizing config
        $config = array(
            array(
                'image_library' => 'GD2',
                'source_image'  => './assets/images/' . $file_name,
                'maintain_ratio' => FALSE,
                'width'         => 370,
                'height'        => 237,
                'new_image'     => './assets/images/thumb/' . $file_name
            )
        );

        $this->load->library('image_lib', $config[0]);
        foreach ($config as $item) {
            $this->image_lib->initialize($item);
            if (!$this->image_lib->resize()) {
                return false;
            }
            $this->image_lib->clear();
        }
    }
}
