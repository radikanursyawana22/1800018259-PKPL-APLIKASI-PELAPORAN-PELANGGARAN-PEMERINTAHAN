<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Anon extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_status_pengaduan');
    }

    public function index()
    {
        $data['title'] = 'Tambah aduan';
        $this->load->view('templates_front/header_anon', $data);
        $this->load->view('add_pengaduan_anon', $data);
        $this->load->view('templates_front/footer', $data);
    }

    public function home()
    {
        $data['title'] = 'Home';
        $this->load->view('templates_front/header_anon', $data);
        $this->load->view('home', $data);
        $this->load->view('templates_front/footer', $data);

        // $this->load->view('template/VP_dashboard_admin' );
    }

    public function status_pengaduan()
    {
        $data['title'] = 'Status';
        $this->load->view('templates_front/header_anon', $data);
        $this->load->view('status_pengaduan_anon', $data);
        $this->load->view('templates_front/footer', $data);
    }

    function search()
    {

        $tiket = $this->input->post('tiket');


        if ($this->input->post('tiket') != NULL) {
            $data['title'] = 'Status';
            $x['data'] = $this->m_status_pengaduan->get_tiket($tiket);
            $this->load->view('templates_front/header_anon', $data);
            $this->load->view('status_search', $x);
            $this->load->view('templates_front/footer');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('status_pengaduan');
        }
    }

    public function faq()
    {
        $data['title'] = 'FAQ';
        $this->load->view('templates_front/header_anon', $data);
        $this->load->view('faq', $data);
        $this->load->view('templates_front/footer', $data);

        // $this->load->view('template/VP_dashboard_admin' );


    }
}
