<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Status_pengaduan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_status_pengaduan');
    }

    public function index()
    {
        if ($this->session->userdata('role_id') != NULL) {
            $data['title'] = 'Status Pengaduan';
            $this->load->view('templates_front/header', $data);
            $this->load->view('status_pengaduan', $data);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }

    function search()
    {

        $tiket = $this->input->post('tiket');


        if ($this->input->post('tiket') != NULL) {
            $data['title'] = 'Status';
            $x['data'] = $this->m_status_pengaduan->get_tiket($tiket);
            $this->load->view('templates_front/header', $data);
            $this->load->view('status_search', $x);
            $this->load->view('templates_front/footer');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('status_pengaduan');
        }
    }
}
