<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

    public function index()
    {


        // $this->load->view('template/VP_dashboard_admin' );
        if ($this->session->userdata('role_id') != NULL) {
            $data['title'] = 'Home';
            $this->load->view('templates_front/header', $data);
            $this->load->view('home', $data);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }
}
