<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
    }

    public function index()
    {
        $this->load->model('M_user');
        $post_id =  $this->session->userdata('username');
        $x['data'] = $this->M_user->get_post_by_id($post_id);
        $data['title'] = 'My profile';

        if ($this->session->userdata('role_id') != NULL) {
            $this->load->view('templates_front/header', $data);
            $this->load->view('profile', $x);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }

    public function change_password()
    {
        $data['title'] = 'Change password';
        $this->load->model('M_user');
        $post_id =  $this->session->userdata('username');
        $x['data'] = $this->M_user->get_current_pass($post_id);
        if ($this->input->post('change_pass')) {
            $old_pass = $this->input->post('old_pass');
            $current_pass = $this->input->post('password');
            $hashed = $current_pass;
            $new_pass = $this->input->post('new_pass');
            $confirm_pass = $this->input->post('confirm_pass');

            if (password_verify($old_pass, $hashed)) {
                if (!strcmp($new_pass, $confirm_pass)) {
                    $this->M_user->change_pass($post_id, password_hash($new_pass, PASSWORD_BCRYPT));
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password Updated Successfully! </div>');
                    redirect('user/change_password');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New password is not matching </div>');
                    redirect('user/change_password');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Current password is incorrect </div>');
                redirect('user/change_password');
            }
        }
        if ($this->session->userdata('role_id') != NULL) {
            $data['title'] = 'My Profile';
            $this->load->view('templates_front/header', $data);
            $this->load->view('change_pass', $x);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }


    public function get_edit()
    {
        $this->load->model('M_user');
        if ($this->session->userdata('role_id') != NULL) {
            $data['title'] = 'Get Edit';
            $post_id =  $this->session->userdata('username');
            $x['data'] = $this->M_user->get_user($post_id);
            $this->load->view('templates_front/header', $data);
            $this->load->view('get_edit', $x);
            $this->load->view('templates_front/footer', $data);
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Please login first! </div>');
            redirect('auth');
        }
    }


    function edit()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'username already registered!'
        ]);
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('telepon', 'telepon', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');

        if (($this->form_validation->run() == true) && ($this->session->userdata('role_id') != NULL)) {
            $username =  $this->session->userdata('username');
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $phone = $this->input->post('phone');

            $this->M_user->edit($username, $name, $email, $phone);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data pending, admin will review your changes first! </div>');
            redirect('user/');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Upload Foto/File bukti! </div>');
            redirect('user/get_edit');
        }
    }

    public function registration()
    {

        if (($this->form_validation->run() == false) && ($this->session->userdata('role_id') != NULL)) {
            $this->load->view('auth/registration');
        } else {
            $this->M_user->edit($username, $name, $email, $phone);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Account registered successfully. Please login </div>');
            redirect('auth');
        }
    }

    function get_user($post_id)
    {
        $result = $this->db->query("SELECT * FROM pengaduan WHERE username='$post_id'");
        return $result;
    }
}
