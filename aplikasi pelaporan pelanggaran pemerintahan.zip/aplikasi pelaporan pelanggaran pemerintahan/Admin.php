<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function index()
    {
        $data['title'] = 'Dashboard';

        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $this->db->select('*');
        $this->db->from('pengaduan');
        $this->db->like('status', 'Pengaduan Baru');
        $data['baru'] = $this->db->count_all_results();

        $this->db->select('*');
        $this->db->from('pengaduan');
        $this->db->like('status', 'Sedang Diverifikasi');
        $data['diverifikasi'] = $this->db->count_all_results();

        $this->db->select('*');
        $this->db->from('pengaduan');
        $this->db->like('status', 'Pengaduan Diterima');
        $data['diterima'] = $this->db->count_all_results();

        $this->db->select('*');
        $this->db->from('pengaduan');
        $this->db->like('status', 'Pengaduan Ditolak');
        $data['ditolak'] = $this->db->count_all_results();


        if ($this->session->userdata('role_id') === '1') {
            $this->load->view('templates_back/header', $data);
            $this->load->view('templates_back/sidebar');
            $this->load->view('templates_back/topbar', $data);
            $this->load->view('admin/index', $data);
            // $this->load->view('template/VP_dashboard_admin' );

            $this->load->view('templates_back/footer');
        } elseif ($this->session->userdata('role_id') === '2') {
            $this->session->unset_userdata('username');
            $this->session->unset_userdata('role_id');

            redirect('auth');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Admin Only! </div>');
            redirect('auth');
        }
    }

    public function change_password()
    {
        $data['title'] = 'Change password';
        $this->load->model('m_user');
        $post_id =  $this->session->userdata('username');
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $x['data'] = $this->m_user->get_current_pass($post_id);
        if ($this->input->post('change_pass')) {
            $old_pass = $this->input->post('old_pass');
            $current_pass = $this->input->post('password');
            $hashed = $current_pass;
            $new_pass = $this->input->post('new_pass');
            $confirm_pass = $this->input->post('confirm_pass');

            if (password_verify($old_pass, $hashed)) {
                if (!strcmp($new_pass, $confirm_pass)) {
                    $this->m_user->change_pass($post_id, password_hash($new_pass, PASSWORD_BCRYPT));
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password Updated Successfully! </div>');
                    redirect('admin/change_password');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New password is not matching </div>');
                    redirect('admin/change_password');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Current password is incorrect </div>');
                redirect('admin/change_password');
            }
        }
        if ($this->session->userdata('role_id') === '1') {
            $this->load->view('templates_back/header', $data);
            $this->load->view('templates_back/sidebar');
            $this->load->view('templates_back/topbar', $data);
            $this->load->view('admin/change_password', $x);
        } elseif ($this->session->userdata('role_id') === '2') {
            $this->session->unset_userdata('username');
            $this->session->unset_userdata('role_id');

            redirect('auth');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Admin Only! </div>');
            redirect('auth');
        }
    }
}
